const $ = s => document.querySelector(s);
let products = [], cart = JSON.parse(localStorage.getItem("wfj-cart") || "[]"), currentUser = null;
const money = n => "৳" + Number(n).toLocaleString("en-BD");
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url, options={}) {
  const res = await fetch(url, {credentials:"same-origin",headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
function toast(message){const t=$("#toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400)}
function saveCart(){localStorage.setItem("wfj-cart",JSON.stringify(cart));renderCartCount()}
function renderCartCount(){$("#cartCount").textContent=cart.reduce((n,i)=>n+i.qty,0)}
async function loadProducts(){
  try{products=await api("/api/products");renderProducts()}
  catch(e){$("#products").innerHTML='<p class="muted">Could not load products. Check that the server is running.</p>'}
}
function renderProducts(){
  $("#products").innerHTML=products.map(p=>`<article class="product-card"><div class="product-image"><img loading="lazy" src="${esc(p.image || "")}" alt="${esc(p.name)}" onerror="this.src='https://placehold.co/600x800?text=Wahed+Fashion'"><span class="product-tag">${p.stock>0?"IN STOCK":"SOLD OUT"}</span></div><div class="product-info"><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" ${p.stock<1?"disabled":""} onclick="addToCart(${p.id})">${p.stock<1?"Sold out":"+ Add"}</button></div></div></article>`).join("");
}
function addToCart(id){const p=products.find(x=>x.id===id);if(!p||p.stock<1)return toast("This item is out of stock.");const found=cart.find(x=>x.id===id);if(found){if(found.qty>=Math.min(20,p.stock))return toast("Stock limit reached.");found.qty++}else cart.push({id,qty:1});saveCart();toast("Added to your bag.");}
function openDrawer(title,html){$("#drawerTitle").textContent=title;$("#drawerBody").innerHTML=html;$("#overlay").classList.remove("hidden")}
function closeDrawer(){$("#overlay").classList.add("hidden")}
function cartHtml(){if(!cart.length)return '<p class="muted">Your bag is empty. Find something you love.</p><button class="solid-btn" onclick="closeDrawer()">Continue shopping</button>';
 const lines=cart.map(i=>{const p=products.find(x=>x.id===i.id);if(!p)return "";return `<div class="cart-row"><img src="${esc(p.image)}" alt=""><div><h4>${esc(p.name)}</h4><small>${money(p.price)}</small><div class="qty-controls"><button onclick="changeQty(${p.id},-1)">−</button><span>${i.qty}</span><button onclick="changeQty(${p.id},1)">+</button><button class="subtle-btn" onclick="removeItem(${p.id})">Remove</button></div></div><b>${money(p.price*i.qty)}</b></div>`}).join("");
 const total=cart.reduce((sum,i)=>sum+(products.find(p=>p.id===i.id)?.price||0)*i.qty,0);
 return `${lines}<div class="cart-total"><span>Subtotal</span><span>${money(total)}</span></div><p class="muted">Delivery charges, if any, are confirmed by the store.</p><button class="solid-btn" style="width:100%" onclick="checkout()">Continue to checkout</button>`;
}
function showCart(){openDrawer("Your bag",cartHtml())}
function changeQty(id,delta){const item=cart.find(i=>i.id===id);if(!item)return;item.qty+=delta;if(item.qty<1)cart=cart.filter(i=>i.id!==id);saveCart();showCart()}
function removeItem(id){cart=cart.filter(i=>i.id!==id);saveCart();showCart()}
async function checkout(){
 if(!cart.length)return toast("Your bag is empty.");
 if(!currentUser){showAuth("login","Please log in to place your order.");return}
 const total=cart.reduce((s,i)=>s+(products.find(p=>p.id===i.id)?.price||0)*i.qty,0);
 openDrawer("Delivery details",`<p class="muted">Order total: <b>${money(total)}</b></p><form id="checkoutForm" class="form-stack"><label>Delivery address<textarea name="address" required minlength="8" placeholder="House, road, area, city"></textarea></label><label>Phone number<input name="phone" required minlength="6" placeholder="01XXXXXXXXX"></label><label>Payment method<select name="paymentMethod"><option value="cod">Cash on delivery</option><option value="manual">Pay manually (confirm with store)</option></select></label><p class="muted">Online card/mobile-wallet payments are not activated in this starter. Never enter card or PIN details here.</p><button type="submit">Place order</button><p id="checkoutError" class="form-error"></p></form>`);
 $("#checkoutForm").onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.target);try{const result=await api("/api/orders",{method:"POST",body:JSON.stringify({items:cart,address:fd.get("address"),phone:fd.get("phone"),paymentMethod:fd.get("paymentMethod")})});cart=[];saveCart();await loadProducts();openDrawer("Order received",`<h3>Thank you for your order!</h3><p>Your order number is <b>#${result.id}</b>.</p><p class="muted">Total: ${money(result.total)}. Keep your order number for reference.</p><button class="solid-btn" onclick="closeDrawer()">Continue shopping</button>`)}catch(err){$("#checkoutError").textContent=err.message}}
}
function showAuth(mode="login",notice=""){
 const login=mode==="login";
 openDrawer(login?"Welcome back":"Create account",`${notice?`<p class="muted">${esc(notice)}</p>`:""}<form id="authForm" class="form-stack">${login?"":'<label>Your name<input name="name" required minlength="2" placeholder="Full name"></label>'}<label>Email<input name="email" type="email" required placeholder="you@example.com"></label><label>Password<input name="password" type="password" required minlength="8" placeholder="At least 8 characters"></label><button type="submit">${login?"Log in":"Create account"}</button><p id="authError" class="form-error"></p></form><button class="subtle-btn" style="width:100%;margin-top:12px" id="switchAuth">${login?"New here? Create an account":"Already have an account? Log in"}</button>`);
 $("#switchAuth").onclick=()=>showAuth(login?"register":"login");
 $("#authForm").onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.target);try{const data=await api(login?"/api/login":"/api/register",{method:"POST",body:JSON.stringify(Object.fromEntries(fd))});currentUser=data.user;openDrawer("Hello, "+currentUser.name,accountHtml());toast("You are signed in.")}catch(err){$("#authError").textContent=err.message}}
}
function accountHtml(){return `<p class="muted">Signed in as ${esc(currentUser.email)}</p>${currentUser.role==="admin"?'<button class="solid-btn" style="width:100%;margin:12px 0" onclick="showAdmin()">Open admin panel</button>':""}<button class="subtle-btn" style="width:100%;margin:12px 0" onclick="showOrders()">My orders</button><button class="subtle-btn" style="width:100%" onclick="logout()">Log out</button>`}
async function showAccount(){if(!currentUser){showAuth();return}openDrawer("Your account",accountHtml())}
async function logout(){await api("/api/logout",{method:"POST"});currentUser=null;showAuth("login","You have been logged out.");}
async function showOrders(){try{const orders=await api("/api/my-orders");openDrawer("My orders",orders.length?orders.map(o=>`<div class="admin-item"><h4>Order #${o.id} · ${money(o.total)}</h4><p>${new Date(o.created_at+"Z").toLocaleString()} · ${esc(o.status)} · ${esc(o.payment_status)}</p><p>${o.items.map(i=>`${esc(i.name)} × ${i.qty}`).join(", ")}</p></div>`).join(""):'<p class="muted">You have not placed any orders yet.</p>')}catch(e){showAuth()}}
async function showAdmin(){
 if(!currentUser||currentUser.role!=="admin")return toast("Admin access required.");
 try{
 const [orders,allProducts]=await Promise.all([api("/api/admin/orders"),api("/api/products")]);
 openDrawer("Admin panel",`<h3>Orders</h3>${orders.length?orders.map(o=>`<div class="admin-item"><h4>Order #${o.id} · ${money(o.total)}</h4><p>${esc(o.customer_name)} (${esc(o.customer_email)}) · ${esc(o.phone)}</p><p>${esc(o.address)}</p><p>${o.items.map(i=>`${esc(i.name)} × ${i.qty}`).join(", ")}</p><label>Status <select onchange="updateOrder(${o.id},this.value)">${["new","processing","shipped","completed","cancelled"].map(s=>`<option ${s===o.status?"selected":""}>${s}</option>`).join("")}</select></label></div>`).join(""):'<p class="muted">No orders yet.</p>'}<h3 style="margin-top:30px">Products</h3>${allProducts.map(p=>`<div class="admin-item"><h4>${esc(p.name)} · ${money(p.price)}</h4><p>Stock: ${p.stock}</p><button class="subtle-btn" onclick="deleteProduct(${p.id})">Hide product</button></div>`).join("")}<h3 style="margin-top:30px">Add product</h3><form id="productForm" class="form-stack"><label>Product name<input name="name" required></label><label>Description<textarea name="description"></textarea></label><label>Price in taka<input name="price" type="number" min="1" step="1" required></label><label>Stock quantity<input name="stock" type="number" min="0" step="1" required></label><label>Image URL<input name="image" type="url" placeholder="https://..."></label><button>Add product</button><p id="productError" class="form-error"></p></form>`);
 $("#productForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/admin/products",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});toast("Product added.");await loadProducts();showAdmin()}catch(err){$("#productError").textContent=err.message}}
 }catch(e){toast(e.message)}
}
async function updateOrder(id,status){try{await api(`/api/admin/orders/${id}`,{method:"PATCH",body:JSON.stringify({status})});toast("Order status updated.")}catch(e){toast(e.message)}}
async function deleteProduct(id){if(!confirm("Hide this product from the shop?"))return;try{await api(`/api/admin/products/${id}`,{method:"DELETE"});await loadProducts();showAdmin();toast("Product hidden.")}catch(e){toast(e.message)}}
$("#cartBtn").onclick=showCart;$("#accountBtn").onclick=showAccount;$("#closeDrawer").onclick=closeDrawer;$("#overlay").addEventListener("click",e=>{if(e.target.id==="overlay")closeDrawer()});
(async()=>{try{const me=await api("/api/me");currentUser=me.user}catch{}await loadProducts();renderCartCount()})();
