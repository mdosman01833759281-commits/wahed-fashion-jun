require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database(path.join(__dirname, "shop.db"));
const PORT = process.env.PORT || 3000;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  secret: process.env.SESSION_SECRET || "dev-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 7 * 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
 price INTEGER NOT NULL, image TEXT DEFAULT '', stock INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, items_json TEXT NOT NULL,
 total INTEGER NOT NULL, payment_method TEXT NOT NULL, payment_status TEXT NOT NULL DEFAULT 'pending',
 status TEXT NOT NULL DEFAULT 'new', address TEXT NOT NULL, phone TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

const productCount = db.prepare("SELECT COUNT(*) AS n FROM products").get().n;
if (!productCount) {
  const insert = db.prepare("INSERT INTO products (name, description, price, image, stock) VALUES (?, ?, ?, ?, ?)");
  [
    ["Classic Black T-Shirt", "Everyday cotton-style tee with a clean fit.", 650, "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80", 20],
    ["Minimal White Shirt", "A versatile white shirt for casual looks.", 950, "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=900&q=80", 12],
    ["Streetwear Hoodie", "Comfortable hoodie for cooler evenings.", 1450, "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=80", 8],
    ["Everyday Tote Bag", "Simple carry-all bag for daily essentials.", 450, "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=900&q=80", 15]
  ].forEach(p => insert.run(...p));
}

function safeUser(u) { return { id: u.id, name: u.name, email: u.email, role: u.role }; }
function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please log in first." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  next();
}

async function seedAdmin() {
  const email = (process.env.ADMIN_EMAIL || "admin@example.com").toLowerCase();
  const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (!exists) {
    const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD || "ChangeMe123!", 12);
    db.prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')")
      .run(process.env.ADMIN_NAME || "Store Admin", email, hash);
    console.log(`Seeded admin account: ${email} (set ADMIN_PASSWORD in .env before use)`);
  }
}
seedAdmin().catch(console.error);

app.get("/api/products", (req, res) => {
  res.json(db.prepare("SELECT id,name,description,price,image,stock FROM products WHERE active=1 ORDER BY id DESC").all());
});
app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.post("/api/register", async (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8)
    return res.status(400).json({ error: "Enter a name, valid email, and password of at least 8 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (name,email,password_hash) VALUES (?,?,?)").run(name, email, hash);
    req.session.user = { id: result.lastInsertRowid, name, email, role: "customer" };
    res.json({ user: req.session.user });
  } catch (e) {
    if (String(e).includes("UNIQUE")) return res.status(409).json({ error: "That email is already registered." });
    res.status(500).json({ error: "Could not create account." });
  }
});
app.post("/api/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash)))
    return res.status(401).json({ error: "Email or password is incorrect." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start session." });
    req.session.user = safeUser(user);
    res.json({ user: req.session.user });
  });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.post("/api/orders", requireAuth, (req, res) => {
  const { items, address, phone, paymentMethod } = req.body;
  if (!Array.isArray(items) || !items.length || items.length > 50) return res.status(400).json({ error: "Your cart is empty or invalid." });
  if (String(address || "").trim().length < 8 || String(phone || "").trim().length < 6) return res.status(400).json({ error: "Enter a delivery address and phone number." });
  if (!["cod", "manual"].includes(paymentMethod)) return res.status(400).json({ error: "Unsupported payment method." });
  const getProduct = db.prepare("SELECT id,name,price,stock FROM products WHERE id=? AND active=1");
  const reduceStock = db.prepare("UPDATE products SET stock=stock-? WHERE id=? AND stock>=?");
  const insertOrder = db.prepare("INSERT INTO orders (user_id,items_json,total,payment_method,payment_status,address,phone) VALUES (?,?,?,?,?,?,?)");
  try {
    const create = db.transaction(() => {
      let total = 0; const normalized = [];
      for (const item of items) {
        const id = Number(item.id), qty = Number(item.qty);
        if (!Number.isInteger(id) || !Number.isInteger(qty) || qty < 1 || qty > 20) throw new Error("Invalid item quantity.");
        const p = getProduct.get(id);
        if (!p || p.stock < qty) throw new Error(`Not enough stock for ${p ? p.name : "an item"}.`);
        total += p.price * qty;
        normalized.push({ id: p.id, name: p.name, price: p.price, qty });
      }
      for (const item of normalized) {
        if (!reduceStock.run(item.qty, item.id, item.qty).changes) throw new Error(`Stock changed for ${item.name}. Please retry.`);
      }
      const result = insertOrder.run(req.session.user.id, JSON.stringify(normalized), total, paymentMethod,
        paymentMethod === "cod" ? "pay-on-delivery" : "pending", String(address).trim(), String(phone).trim());
      return { id: result.lastInsertRowid, total };
    });
    res.status(201).json(create());
  } catch (e) { res.status(400).json({ error: e.message || "Could not place order." }); }
});

app.get("/api/my-orders", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT id,items_json,total,payment_method,payment_status,status,address,phone,created_at FROM orders WHERE user_id=? ORDER BY id DESC").all(req.session.user.id);
  res.json(rows.map(o => ({ ...o, items: JSON.parse(o.items_json) })));
});

app.get("/api/admin/orders", requireAdmin, (req, res) => {
  const rows = db.prepare(`SELECT orders.*, users.name AS customer_name, users.email AS customer_email
    FROM orders JOIN users ON users.id=orders.user_id ORDER BY orders.id DESC`).all();
  res.json(rows.map(o => ({ ...o, items: JSON.parse(o.items_json) })));
});
app.patch("/api/admin/orders/:id", requireAdmin, (req, res) => {
  const allowed = ["new", "processing", "shipped", "completed", "cancelled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "Invalid order status." });
  const result = db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Order not found." });
  res.json({ ok: true });
});
app.post("/api/admin/products", requireAdmin, (req, res) => {
  const name = String(req.body.name || "").trim();
  const description = String(req.body.description || "").trim();
  const image = String(req.body.image || "").trim();
  const price = Number(req.body.price), stock = Number(req.body.stock);
  if (name.length < 2 || !Number.isInteger(price) || price < 1 || !Number.isInteger(stock) || stock < 0)
    return res.status(400).json({ error: "Name, positive whole-number price, and non-negative stock are required." });
  const result = db.prepare("INSERT INTO products (name,description,price,image,stock) VALUES (?,?,?,?,?)").run(name, description, price, image, stock);
  res.status(201).json({ id: result.lastInsertRowid });
});
app.delete("/api/admin/products/:id", requireAdmin, (req, res) => {
  const result = db.prepare("UPDATE products SET active=0 WHERE id=?").run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Product not found." });
  res.json({ ok: true });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Wahed Fashion Jun is running at http://localhost:${PORT}`));
